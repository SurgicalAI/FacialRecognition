# 11 line face recognition
Face Recognition in just 11 lines of code.

Using OpenCV 

Full tutorial on:
https://itsaihub.com/?p=2423


# HOW TO RUN ::
On Terminal Type:

> python face-detect.py image.webp


Change image.webp to any of your image.
Thats it.
